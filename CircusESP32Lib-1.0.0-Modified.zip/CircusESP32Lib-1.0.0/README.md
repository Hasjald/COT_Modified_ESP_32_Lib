# CircusESP32Lib-1.0.0
Implements the circusofthings API when used with ESP32 board
